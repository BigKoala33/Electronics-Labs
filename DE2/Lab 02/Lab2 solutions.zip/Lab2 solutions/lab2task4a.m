% Lab 2 - Task 4a - Explore effect of using Hamming Window
%
clear all
ports = serialportlist;     % find all serial port
pb = PyBench(ports(end));   % create a PyBench object with last port

% Set sampling frequency
fs = 8000;
pb = pb.set_samp_freq(fs);

% Capture N samples
N = 1000;
samples = pb.get_mic(N);
data = samples - mean(samples);  % remove dc offset

% plot data
figure(1);
clf
plot(data);
xlabel('Sample no');
ylabel('Signal voltage (V)');
title('Microphone signal');
% find spectrum
figure(2);
plot_spec_dB(data, fs);

% create a hamming window
window = hamming(length(data));
while true
    samples = pb.get_mic(N);
    data = samples - mean(samples);
    clf;
    plot_spec_dB(data,fs);
    hold on               % over plot figure
    plot_spec_dB(data.*window,fs);
end

