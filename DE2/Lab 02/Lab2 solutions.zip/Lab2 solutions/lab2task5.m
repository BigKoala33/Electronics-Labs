% Lab 2 - Task 5 - Analyse Two drum beats
%
clear all
[sig fs] = audioread('two_drums.wav');
sound(sig, fs)      % play the signal on speaker
% plot the signal
figure(1);
clf;
plot(sig);
xlabel('Sample no');
ylabel('Signal (v)');
title('Two Drums');

% Divide signal into segments and find its energy
T = 0.02;       % divide signal into 20ms segments
N = fs*T;       % for this duration, we need N samples
E = [];
for i=1:N:length(sig)-N+1
    seg = sig(i:i+N-1);
    E = [E seg'*seg];
end
% plot the energy graph and the peak values
figure(2);
clf;
x = 1:length(E);
plot(x, E)
xlabel('Segment number');
ylabel('Energy');
hold on
% Find local maxima
[pks locs] = findpeaks(E);
plot(locs, pks, 'o');
hold off
% plot spectrum of energy
figure(3)
plot_spec(E - mean(E), 1/T);