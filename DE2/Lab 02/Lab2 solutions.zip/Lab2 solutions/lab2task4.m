% Lab 2 - Task 4 - Plotting microphone spectrum in dB
%
clear all
ports = serialportlist;     % find all serial port
pb = PyBench(ports(end));   % create a PyBench object with last port

% Set sampling frequency
fs = 8000;
pb = pb.set_samp_freq(fs);

% Capture N samples
N = 1000;
samples = pb.get_mic(N);
data = samples - mean(samples);  % remove dc offset

% plot data
figure(1);
clf
plot(data);
xlabel('Sample no');
ylabel('Signal voltage (V)');
title('Microphone signal');
% find spectrum
figure(2);
plot_spec_dB(data, fs);

%  repeat capture and plot spectrum in dB
while true
    samples = pb.get_mic(N);
    data = samples - mean(samples);
    figure(2)
    clf;
    plot_spec_dB(data,fs);
end
%